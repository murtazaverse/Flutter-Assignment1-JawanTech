package com.example.shahmeerkhan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
